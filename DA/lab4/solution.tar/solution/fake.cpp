#include<iostream>

int main(){
    std::ios::sync_with_stdio(false);
    char a;
    int *i = new int[21], j = 0;
    i[0]=1;
    i[1]=1;
    i[2]=1;
    i[3]=1;
    i[4]=1;
    i[5]=2;
    i[6]=1;
    i[7]=3;
    i[8]=1;
    i[9]=1;
    i[10]=3;
    i[11]=2;
    i[12]=1;
    i[13]=5;
    i[14]=2;
    i[15]=2;
    i[16]=1;
    i[17]=3;
    i[18]=2;
    i[19]=2;
    i[20]=3;
    while(std::cin >> a){
        j++;
    }
    for(int u = 0; u < 21; u+=3){
        std::cout << i[u] << ", " << i[u+1] << ", " << u[i+2] << '\n';
    }
}